import { Component } from '@angular/core';

@Component({
  selector: 'app-articls',
  templateUrl: './articls.component.html',
  styleUrls: ['./articls.component.css']
})
export class ArticlsComponent {

}
